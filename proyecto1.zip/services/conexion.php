<?php
$conexion = mysqli_connect("localhost","gestiona_sergi","00zn754n","gestiona_curs");
